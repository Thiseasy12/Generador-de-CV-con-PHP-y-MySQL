<?php
/**
 *Aqui hacemos la conexion a la base de datos de mysql
 */
$conex = mysqli_connect("localhost", "root", "", "formulario");
?>