<?php
/**
 * incluyo el archivo de conexion a la base de datos
 */
include("conexion.php");

/**
 * Si se recibe un id por la URL para borrar un curriculum
 * borro ese curriculum de la base de datos
 */
// Si llega un id por la URL, se elimina ese currículum
if (isset($_GET["id_borrar"])) {

    // Guardo el id recibido
    $id = $_GET["id_borrar"];

    // Consulta para borrar el cv por el id
    $query_delete = "DELETE FROM datos WHERE id = $id";
    mysqli_query($conex, $query_delete);

    // Vuelvo al historial una vez lo borre
    header("Location: historial.php");
    exit();
}

// Obtengo todos los CV guardados de forma descendente para que vaya primeramente desde el id 1
$resultado = mysqli_query($conex, "SELECT * FROM datos ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Historial de Versiones</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body class="index-body">
    <div class="container"
        style="background: white; padding: 30px; border-radius: 10px; margin-top: 50px; color: #333;">
        <h4 class="center-align" style="color: #26a69a;">CVs Guardados</h4>
        <!-- Tabla donde se muestran los currículums guardados -->
        <table class="striped responsive-table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php

                // Recorro todos los registros obtenidos de la base de datos
                while ($fila = mysqli_fetch_assoc($resultado)) { ?>
                    <tr>
                        <!-- Muestro el nombre y apellidos de la persona -->
                        <td><?php echo $fila['nombre'] . " " . $fila['apellido']; ?></td>
                        <!-- Muestro la fecha de creacion del cv -->
                        <td><?php echo $fila['fecha']; ?></td>
                        <td>

                            <!--Botones para poder ver editar o eliminar un cv-->
                            <a href="ver_cv.php?id=<?php echo $fila['id']; ?>" class="blue-text">Ver</a> |

                            <a href="editar_cv.php?id=<?php echo $fila['id']; ?>" class="orange-text">Editar</a> |

                            <a href="historial.php?id_borrar=<?php echo $fila['id']; ?>" class="red-text"
                                onclick="return confirm('¿Estás seguro de que quieres eliminar este CV?')">
                                Eliminar
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <br>
        <div class="center-align">
            <!--Boton para crear un nuevo cv desde el hisotrial-->
            <a href="index.html" class="btn waves-effect waves-light">Crear Nuevo CV</a>
        </div>
    </div>
</body>

</html>