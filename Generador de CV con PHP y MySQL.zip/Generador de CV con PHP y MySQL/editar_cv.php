<?php
include("conexion.php");

/*Obtengo los datos del curriculum ya creado*/
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $resultado = mysqli_query($conex, "SELECT * FROM datos WHERE id = $id");
    $fila = mysqli_fetch_assoc($resultado);
}

/**
 * Recojo los datos nuevos que puso el usuario 
 */
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $telefono = $_POST['Telefono'];
    $experiencia = $_POST['Experiencia_laboral'];
    $formacion = $_POST['Formacion_academica'];
    $habilidades = $_POST['Habilidades'];
    $idiomas = $_POST['Idiomas'];
    /**
     * Hago la insercion de los datos nuevos para actualizar los datos de la base de datos
     */
    $sql_update = "UPDATE datos SET 
                    nombre='$nombre', 
                    apellido='$apellido', 
                    email='$email', 
                    telefono='$telefono', 
                    experiencia='$experiencia', 
                    formacion='$formacion', 
                    habilidades='$habilidades', 
                    idiomas='$idiomas' 
                  WHERE id=$id";

    /**
     * Hago la consulta
     */
    if (mysqli_query($conex, $sql_update)) {
        /**
         *Vuelvo al historial una vez lo borre
         */
        header("Location: historial.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Editar CV</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<!--Enseño de nuevo el formulario para que el usuario meta los datos y se recojan en la parte de arriba del codigo-->

<body class="index-body">
    <section class="container" style="background: white; padding: 40px; border-radius: 10px;">
        <h3 class="center-align" style="color: #26a69a;">Editar CV</h3>
        <form method="POST" action="editar_cv.php">
            <input type="hidden" name="id" value="<?php echo $fila['id']; ?>">

            <div class="input-field">
                <input type="text" name="nombre" value="<?php echo $fila['nombre']; ?>" required>
                <label class="active">Nombre</label>
            </div>
            <div class="input-field">
                <input type="text" name="apellido" value="<?php echo $fila['apellido']; ?>" required>
                <label class="active">Apellido</label>
            </div>
            <div class="input-field">
                <input type="email" name="email" value="<?php echo $fila['email']; ?>" required>
                <label class="active">Email</label>
            </div>
            <div class="input-field">
                <input type="tel" name="Telefono" value="<?php echo $fila['telefono']; ?>" required>
                <label class="active">Teléfono</label>
            </div>
            <div class="input-field">
                <input type="text" name="Experiencia_laboral" value="<?php echo $fila['experiencia']; ?>" required>
                <label class="active">Experiencia Laboral</label>
            </div>
            <div class="input-field">
                <input type="text" name="Formacion_academica" value="<?php echo $fila['formacion']; ?>" required>
                <label class="active">Formación Académica</label>
            </div>
            <div class="input-field">
                <input type="text" name="Habilidades" value="<?php echo $fila['habilidades']; ?>" required>
                <label class="active">Habilidades</label>
            </div>
            <div class="input-field">
                <input type="text" name="Idiomas" value="<?php echo $fila['idiomas']; ?>" required>
                <label class="active">Idiomas</label>
            </div>

            <div class="center-align">
                <button class="btn waves-effect waves-light" type="submit" name="update">Guardar Cambios</button>
                <a href="historial.php" class="btn grey">Cancelar</a>
            </div>
        </form>
    </section>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>
</body>

</html>