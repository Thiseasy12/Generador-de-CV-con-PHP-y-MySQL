CREATE DATABASE IF NOT EXISTS `formulario`;
USE `formulario`;

CREATE TABLE IF NOT EXISTS `datos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `experiencia` text NOT NULL,
  `formacion` text NOT NULL,
  `habilidades` varchar(255) NOT NULL,
  `idiomas` varchar(255) NOT NULL,
  `fecha` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;