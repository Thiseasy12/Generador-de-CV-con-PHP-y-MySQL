<?php
/**
 * Incluimos la conexión a la base de datos
 */
include("conexion.php");

/**
 * Verificamos si se ha pasado un ID por la URL
 */
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    /**
     * Consultamos los datos del CV específico mediante su ID
     */
    $query = "SELECT * FROM datos WHERE id = $id";
    $resultado = mysqli_query($conex, $query);

    /**
     * Si existe consigo los datos del CV
     */
    if ($fila = mysqli_fetch_assoc($resultado)) {
        $nombre = $fila['nombre'];
        $apellido = $fila['apellido'];
        $email = $fila['email'];
        $telefono = $fila['telefono'];
        $experiencia = $fila['experiencia'];
        $formacion = $fila['formacion'];
        $habilidades = $fila['habilidades'];
        $idiomas = $fila['idiomas'];
        $fecha = $fila['fecha'];
    } else {
        /**
         * En caso de que no haya curriculum tirara este echo
         */
        echo "El currículum no existe.";
        exit;
    }
} else {
    header("Location: historial.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Curriculum de <?php echo $nombre; ?></title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="cv-body">
    <div class="menu-acciones no-print">
        <!--Opciones dentro de ver el curriculum-->
        <button class="btn-print" onclick="window.print()">GENERAR PDF</button>
        <a href="historial.php" class="btn-nav">VOLVER AL HISTORIAL</a>
        <a href="editar_cv.php?id=<?php echo $id; ?>" class="btn-nav">EDITAR ESTE CV</a>
        <a href="index.html" class="btn-nav dark">NUEVO CV</a>
    </div>

    <div class="hoja-cv">
        <div class="lateral">
            <!--Parte lateral del cv que tiene un color azul oscuro y los datos de contacto
                idiomas,habilidades  -->
            <h2>CONTACTO</h2>
            <p><b>Tel:</b><br><?php echo $telefono; ?></p>
            <p><b>Email:</b><br><?php echo $email; ?></p>

            <br>
            <h2>IDIOMAS</h2>
            <p><?php echo $idiomas; ?></p>

            <br>
            <h2>HABILIDADES</h2>
            <p><?php echo $habilidades; ?></p>
        </div>

        <div class="principal">
            <!--Parte de la derecha del cv que tienelos datos de expereicnia laboral,formacion y 
                la fecha de cuando se creo  -->
            <h1><?php echo $nombre . " " . $apellido; ?></h1>

            <div class="seccion">
                <h3>EXPERIENCIA LABORAL</h3>
                <p><?php echo $experiencia; ?></p>
            </div>

            <div class="seccion">
                <h3>FORMACIÓN ACADÉMICA</h3>
                <p><?php echo $formacion; ?></p>
            </div>

            <p class="fecha-generacion">
                Curriculum generado originalmente el<?php echo $fecha; ?>
            </p>
        </div>
    </div>
</body>

</html>