<?php
/**
 * incluyo el archivo de conexion a la base de datos
 */
include("conexion.php");

if (isset($_POST['send'])) {
    /**
     * Recojo todos los datos de los campos que el usuario ponga
     */
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $telefono = $_POST['Telefono'];
    $experiencia = $_POST['Experiencia_laboral'];
    $formacion = $_POST['Formacion_academica'];
    $habilidades = $_POST['Habilidades'];
    $idiomas = $_POST['Idiomas'];
    // Guardo la fecha actual para saber cuándo se generó el CV
    $fecha = date("d/m/Y");

    /**
     * Hago la insercion en los campos dentro de la base de datos con todos los datos que el usuario puso
     */
    $sql = "INSERT INTO datos (nombre, apellido, email, telefono, experiencia, formacion, habilidades, idiomas, fecha) 
            VALUES ('$nombre', '$apellido', '$email', '$telefono', '$experiencia', '$formacion', '$habilidades', '$idiomas', '$fecha')";

    /**
     * Hago la consulta
     */
    $resultado = mysqli_query($conex, $sql);

    /**
     * Si lols datos se han insertado en la base de datos, muestro el curriculum ya creado
     */
    if ($resultado) {
        ?>
        <!DOCTYPE html>
        <html lang="es">

        <head>
            <meta charset="UTF-8">
            <title>Curriculum de <?php echo $nombre; ?></title>
            <link rel="stylesheet" href="style.css">
        </head>

        <body class="cv-body">
            <div class="menu-acciones no-print">
                <!--Botones para ver el historial,imprimir el cv en pdf ocrear un nuevo curriculum-->
                <button class="btn-print" onclick="window.print()">GENERAR PDF</button>
                <a href="historial.php" class="btn-nav">VER HISTORIAL</a>
                <a href="index.html" class="btn-nav dark">NUEVO CV</a>
            </div>

            <div class="hoja-cv">
                <!--Parte lateral del cv que tiene un color azul oscuro y los datos de contacto
                idiomas,habilidades  -->
                <div class="lateral">
                    <h2>CONTACTO</h2>
                    <p><b>Tel:</b><br><?php echo $telefono; ?></p>
                    <p><b>Email:</b><br><?php echo $email; ?></p>

                    <br>
                    <h2>IDIOMAS</h2>
                    <p><?php echo $idiomas; ?></p>

                    <br>
                    <h2>HABILIDADES</h2>
                    <p><?php echo $habilidades; ?></p>
                </div>
                <!--Parte de la derecha del cv que tienelos datos de expereicnia laboral,formacion y 
                la fecha de cuando se creo  -->
                <div class="principal">
                    <h1><?php echo $nombre . " " . $apellido; ?></h1>

                    <div class="seccion">
                        <h3>EXPERIENCIA LABORAL</h3>
                        <p><?php echo $experiencia; ?></p>
                    </div>

                    <div class="seccion">
                        <h3>FORMACION ACADÉMICA</h3>
                        <p><?php echo $formacion; ?></p>
                    </div>

                    <p class="fecha-generacion">
                        Curriculum generado el <?php echo $fecha; ?>
                    </p>
                </div>
            </div>
        </body>

        </html>
        <?php
    }
}
?>